# JWT Authorization and Token Refresh - Angular Academy

Angular part of video lesson:

[JWT Authorization and Token Refresh](https://www.youtube.com/watch?v=F1GUjHPpCLA)

<p align="center">
  
[<img src="https://github.com/bartosz-io/jwt-auth-angular/blob/master/image.png">](https://www.youtube.com/watch?v=F1GUjHPpCLA)

[<img src="https://github.com/bartosz-io/jwt-auth-angular/blob/master/sub.jpg">](https://www.youtube.com/channel/UCcJutJNPZVG5sbp_xaTmKEw?sub_confirmation=1)

</p>
