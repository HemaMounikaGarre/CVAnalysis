export class RandomNumber {
  value: number;
}
